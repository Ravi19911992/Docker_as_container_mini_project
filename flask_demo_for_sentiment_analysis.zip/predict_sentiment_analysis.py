import nltk
import re
import pickle
from nltk import data
from string import punctuation
from nltk.corpus import stopwords 
from nltk.tokenize import word_tokenize
import json

#from nltk import download
#download('punkt',download_dir=data.path[0])
#download('stopwords',download_dir=data.path[0])
#download('wordnet',download_dir=data.path[0])
# #THEN remove the zip files!

nltk.download('stopwords')
nltk.download('punkt')

stopwords_eng = stopwords.words("english")
stemmer = nltk.SnowballStemmer("english")

def extract_features(words):
    return [stemmer.stem(w) for w in words if w not in stopwords_eng and w not in punctuation]

def bag_of_words(words):
    bag = {}
    for w in words:
      w1= w.lower()
      bag[w1] = bag.get(w1,0)+1
    return bag


model_file = open("sa_classifier.pickle", "rb")
model = pickle.load(model_file)
model_file.close()


def get_sentiment(review):
    words = word_tokenize(review)
    words = extract_features(words)
    words = bag_of_words(words)
    return model.classify(words)

def predict(event,context):
    review = event['body']
    return { 'statusCode': 200, 'body': json.dumps(get_sentiment(review)) }

#predict({"body":"This movie is amazing, with witty dialog and beautiful shots."}, None)
